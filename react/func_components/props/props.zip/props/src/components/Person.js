import React from "react";

const Person = (props) => {
    return (
        <div>
            <h3> {props.lname}, {props.fname}   </h3>
            <p>Age : {props.age} </p>
            <p> Hair color : {props.haircolor} </p>
        </div>
    )
}

export default Person